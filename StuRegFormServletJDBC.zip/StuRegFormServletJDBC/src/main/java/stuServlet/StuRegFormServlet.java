package stuServlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StuRegFormServlet")
public class StuRegFormServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        response.setCharacterEncoding("UTF-8");

        response.getWriter().println("<h1>Submitted Successfully</h1>");

        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
        String Name = request.getParameter("Name");
        String Password = request.getParameter("Password");
        String Email = request.getParameter("Email");
        long ContactDetails = Long.parseLong(request.getParameter("ContactDetails"));
        String Address = request.getParameter("Address");
        String City = request.getParameter("City");
        long Pincode = Long.parseLong(request.getParameter("Pincode"));
        Date DOB = null;
        try {
            DOB = new Date(dateFormat.parse(request.getParameter("DOB")).getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        String Gender = request.getParameter("Gender");
        String Nationality = request.getParameter("Nationality");
        String ParentName = request.getParameter("GuardianName");
        String ParentEmail = request.getParameter("GuardianEmail");
        long EmergencyContact = Long.parseLong(request.getParameter("EmContact"));
        String PrevClgName = request.getParameter("PrevCollege");
        String Course = request.getParameter("Course");
        String PrefLanguage = request.getParameter("Language");
        String IntrestedinUpdates = request.getParameter("Updates");

        Connection ConnObj = null;
		
		
			try {
				Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
				ConnObj=DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
				PreparedStatement pstmt = ConnObj.prepareStatement("INSERT INTO sturegform VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
				pstmt.setString(1, Name);
				pstmt.setString(2, Password); // Store hashed password instead
				pstmt.setString(3, Email);
				pstmt.setLong(4, ContactDetails);
				pstmt.setString(5, Address);
				pstmt.setString(6, City);
				pstmt.setLong(7, Pincode);
				pstmt.setDate(8, DOB);
				pstmt.setString(9, Gender);
				pstmt.setString(10, Nationality);
				pstmt.setString(11, ParentName);
				pstmt.setString(12, ParentEmail);
				pstmt.setLong(13, EmergencyContact);
				pstmt.setString(14, PrevClgName);
				pstmt.setString(15, Course);
				pstmt.setString(16, PrefLanguage);
				pstmt.setString(17, IntrestedinUpdates);

				pstmt.executeUpdate();
				System.out.println("Data Inserted Successfully");
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        
    }
}
