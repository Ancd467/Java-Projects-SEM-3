package Set4;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Set1.Menu;
import Set2.Menu2;

public class Login4 extends JFrame {
	
	public Login4() {
		// TODO Auto-generated constructor stub
		JLabel lblFactor,lblNumber;
		JTextField txtfactor,txtnumber;
		JButton btnLogin;
		
		lblFactor = new JLabel("Factor : ");
		lblNumber = new JLabel("Number :");
		txtfactor = new JTextField(10);
		txtnumber = new JTextField(10);
		btnLogin = new JButton("Login");
		
		
		add(lblFactor);
		add(txtfactor);
		add(lblNumber);
		add(txtnumber);
		add(btnLogin);
		
		
		btnLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				int factor = Integer.parseInt(txtfactor.getText());
				int number = Integer.parseInt(txtnumber.getText());
				
				if(number % factor == 0 )
				{
					Menu4 frame = new Menu4();
					frame.setLayout(new FlowLayout());
					frame.setSize(500,500);
					frame.setVisible(true);
				}
				else
				{
					System.out.println("Login Unsuccessful");
				}
				
			}
		});
		
	}

}
