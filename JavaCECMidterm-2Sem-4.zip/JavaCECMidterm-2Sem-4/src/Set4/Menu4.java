package Set4;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import Set1.RegisterUserJDBC;
import Set1.SearchUserJDBC;

public class Menu4 extends JFrame {
	
	public Menu4() {
		// TODO Auto-generated constructor stub
		JMenuBar Menu;
		JMenu MnRegister,MnSearch;
		JMenuItem MIEnterSports,MISearchSports;
		
		Menu = new JMenuBar();
		MnRegister = new JMenu("Register");
		MnSearch = new JMenu("Search");
		MIEnterSports = new JMenuItem("Enter Sports");
		MISearchSports = new JMenuItem("Search Sports by Category");
		
		setJMenuBar(Menu);
		Menu.add(MnRegister);
		Menu.add(MnSearch);
		MnRegister.add(MIEnterSports);
		MnSearch.add(MISearchSports);
		
		MIEnterSports.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				EnterSportsByCategory frame = new EnterSportsByCategory();
				frame.setLayout(new FlowLayout());
				frame.setSize(500, 500);
				frame.setVisible(true);
			}
		});
		
		MISearchSports.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				SearchSportsByCategory frame = new SearchSportsByCategory();
				frame.setLayout(new FlowLayout());
				frame.setSize(500, 500);
				frame.setVisible(true);
			}
		});
		
	}
}

