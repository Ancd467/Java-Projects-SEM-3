package Set4;

import java.awt.FlowLayout;

public class Main4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login4 frame = new Login4();
		frame.setLayout(new FlowLayout());
		frame.setSize(500, 500);
		frame.setVisible(true);

	}

}
