package Set4;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class EnterSportsByCategory extends JFrame{
	
	public EnterSportsByCategory() {
		// TODO Auto-generated constructor stub
		JTextField txtSportsName;
		JRadioButton RbtnIndoor,RbtnOutdoor;
		JLabel lblSportsName,lblCategory,lblDataEntered;
		JButton btnSave;
		
		txtSportsName = new JTextField(10);
		RbtnIndoor = new JRadioButton("Indoor");
		RbtnOutdoor = new JRadioButton("Outdoor");
		ButtonGroup CategoryGrp = new ButtonGroup();
		lblSportsName = new JLabel("Sports Name : ");
		lblCategory = new JLabel("Category : ");
		lblDataEntered = new JLabel();
		btnSave = new JButton("Save");
		
		add(lblSportsName);
		add(txtSportsName);
		add(lblCategory);
		CategoryGrp.add(RbtnIndoor);
		CategoryGrp.add(RbtnOutdoor);
		add(RbtnIndoor);
		add(RbtnOutdoor);
		add(btnSave);
		add(lblDataEntered);
		
		
		RbtnIndoor.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				RbtnOutdoor.setEnabled(false);
				
			}
		});
		
		RbtnOutdoor.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				RbtnOutdoor.setEnabled(false);
				
			}
		});
		
		
		btnSave.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			    	
			    	Connection ConnObj = null;
					try {
						Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
						ConnObj=DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
						
						
						System.out.print("Entering Data to Table  : \n");
						
						String Category = "";
						String SportsName = txtSportsName.getText();
						
						if(RbtnIndoor.isSelected())
						{
							Category = " Indoor ";
						}
						if(RbtnOutdoor.isSelected())
						{
							Category = " Outdoor ";
						}

												
						PreparedStatement PrStm = ConnObj.prepareStatement("insert into set4 values (?,?)");
						PrStm.setString(1,SportsName);
						PrStm.setString(4, Category);
						PrStm.executeUpdate();
						
						System.out.print("data Entered \n");
						
					    
						ConnObj.close();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					lblDataEntered.setText("Data Entered ");
					System.out.println("Car namesssss");
					txtSportsName.setText("");
					RbtnIndoor.setEnabled(true);
					RbtnOutdoor.setEnabled(true);
				}
			
				
		});
	}

}
