package Set2;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Set1.Menu;

public class Login2 extends JFrame{

	public Login2() {
		// TODO Auto-generated constructor stub
		JLabel lbl5Multiple,lbl10Multiple;
		JTextField txt5Multiple,txt10Multiple;
		JButton btnLogin;
		
		lbl5Multiple = new JLabel("Multiple of 5 : ");
		lbl10Multiple= new JLabel("Multiple of 10 :");
		txt5Multiple = new JTextField(10);
		txt10Multiple = new JTextField(10);
		btnLogin = new JButton("Login");
		
		
		add(lbl5Multiple);
		add(txt5Multiple);
		add(lbl10Multiple);
		add(txt10Multiple);
		add(btnLogin);
		
		
		btnLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				int FiveMultiple = Integer.parseInt(txt5Multiple.getText());
				int TenMultiple = Integer.parseInt(txt10Multiple.getText());
				int Sum = FiveMultiple + TenMultiple;
				
				if(FiveMultiple % 5 == 0 && TenMultiple % 10 == 0 && Sum>100)
				{
					Menu2 frame = new Menu2();
					frame.setLayout(new FlowLayout());
					frame.setSize(500,500);
					frame.setVisible(true);
				}
				else
				{
					System.out.println("Login Unsuccessful");
				}
				
			}
		});
		
	}
	}

