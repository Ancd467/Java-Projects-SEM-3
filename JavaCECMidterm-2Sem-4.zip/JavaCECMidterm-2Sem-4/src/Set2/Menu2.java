package Set2;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import Set1.RegisterUserJDBC;
import Set1.SearchUserJDBC;

public class Menu2 extends JFrame{
	
	public Menu2() {
		// TODO Auto-generated constructor stub
		JMenuBar Menu;
		JMenu MnRegister,MnShow;
		JMenuItem MIRegEmp,MISortedEmp;
		
		Menu = new JMenuBar();
		MnRegister = new JMenu("Register");
		MnShow = new JMenu("Search");
		MIRegEmp = new JMenuItem("Register an User");
		MISortedEmp = new JMenuItem("Search an User");
		
		setJMenuBar(Menu);
		Menu.add(MnRegister);
		Menu.add(MnShow);
		MnRegister.add(MIRegEmp);
		MnShow.add(MISortedEmp);
		
		MIRegEmp.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				RegisterEmp frame = new RegisterEmp();
				frame.setLayout(new FlowLayout());
				frame.setSize(500, 500);
				frame.setVisible(true);
			}
		});
		
		MISortedEmp.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				SearchUserJDBC frame = new SearchUserJDBC();
				frame.setLayout(new FlowLayout());
				frame.setSize(500, 500);
				frame.setVisible(true);
			}
		});
		
	}
	}


