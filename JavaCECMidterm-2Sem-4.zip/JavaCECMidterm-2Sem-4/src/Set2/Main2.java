package Set2;

import java.awt.FlowLayout;

import Set2.Login2;

public class Main2 {
	public static void main(String[] args) {
		
		Login2 frame = new Login2();
		frame.setLayout(new FlowLayout());
		frame.setSize(500, 500);
		frame.setVisible(true);
	}

}
