package Set2;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class RegisterEmp extends JFrame{
	
	public RegisterEmp() {
		// TODO Auto-generated constructor stub
		JTextField txtName,txtEmail,txtSalary;
		JRadioButton RbtnMale,RbtnFemale;
		JLabel lblName,lblEmail,lblSalary,lblGender,lblDataEntered;
		JButton btnSave;
		
		txtName = new JTextField(10);
		txtEmail = new JTextField(10);
		txtSalary = new JTextField(10);
		RbtnMale = new JRadioButton("Male");
		RbtnFemale = new JRadioButton("Female");
		ButtonGroup GenGrp = new ButtonGroup();
		lblName = new JLabel("Name : ");
		lblEmail = new JLabel("Email : ");
		lblSalary = new JLabel("Salary : ");
		lblGender = new JLabel("Gender : ");
		lblDataEntered = new JLabel();
		btnSave = new JButton("Save");
		
		add(lblName);
		add(txtName);
		add(lblEmail);
		add(txtEmail);
		add(lblSalary);
		add(txtSalary);
		add(lblGender);
		GenGrp.add(RbtnMale);
		GenGrp.add(RbtnFemale);
		add(RbtnMale);
		add(RbtnFemale);
		add(btnSave);
		add(lblDataEntered);
		
		btnSave.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			    	
			    	Connection ConnObj = null;
					try {
						Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
						ConnObj=DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
						
						
						System.out.print("Entering Data to Table  : \n");
						
						String Gender = "";
						String Name = txtName.getText();
						String Email = txtEmail.getText();
						int Salary = Integer.parseInt(txtSalary.getText());
						
						if(RbtnMale.isSelected())
						{
							Gender = "Male";
						}
						if(RbtnFemale.isSelected())
						{
							Gender = "Female";
						}

												
						PreparedStatement PrStm = ConnObj.prepareStatement("insert into set2 values (?,?,?,?)");
						PrStm.setString(1,Name);
						PrStm.setString(2, Email);
						PrStm.setInt(3,Salary);
						PrStm.setString(4, Gender);
						PrStm.executeUpdate();
						
						System.out.print("data Entered \n");
						
					    
						ConnObj.close();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					lblDataEntered.setText("Data Entered ");
					System.out.println("Car namesssss");
					txtName.setText("");
					txtEmail.setText("");
					txtSalary.setText("");
				}
				
		});
		
	}
	}


