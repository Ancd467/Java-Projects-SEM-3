package Set5;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Set1.Menu;

public class Login5 extends JFrame{

	public Login5() {
		// TODO Auto-generated constructor stub
		JLabel lblSum,lblNum;
		JTextField txtSum,txtNum;
		JButton btnLogin;
		
		lblSum = new JLabel("Sum of all Digit : ");
		lblNum= new JLabel("Number :");
		txtSum = new JTextField(10);
		txtNum = new JTextField(10);
		btnLogin = new JButton("Login");
		
		
		add(lblSum);
		add(txtSum);
		add(lblNum);
		add(txtNum);
		add(btnLogin);
		
		
		btnLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				int Sum = Integer.parseInt(txtSum.getText());
				int Number = Integer.parseInt(txtNum.getText());
				
		        int DigitSum = 0;
		        while (Number != 0) {
		            DigitSum += Number % 10; 
		            Number /= 10; 
		        }

		        if (Sum == DigitSum)
				{
					Menu5 frame = new Menu5();
					frame.setLayout(new FlowLayout());
					frame.setSize(500,500);
					frame.setVisible(true);
				}
				else
				{
					System.out.println("Login Unsuccessful");
				}
				
			}
		});
		
	}
	}

