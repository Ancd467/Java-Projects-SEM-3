package Set5;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class RegisterBike extends JFrame{
	
	public RegisterBike() {
		// TODO Auto-generated constructor stub
		JTextField txtName,txtEmail,txtPrice;
		JRadioButton RbtnSports,RbtnEconomical;
		JLabel lblName,lblEmail,lblPrice,lblType,lblDataEntered;
		JButton btnSave;
		
		txtName = new JTextField(10);
		txtEmail = new JTextField(10);
		txtPrice = new JTextField(10);
		RbtnSports = new JRadioButton("Sports");
		RbtnEconomical = new JRadioButton("Econimical");
		ButtonGroup TypeGrp = new ButtonGroup();
		lblName = new JLabel("Name : ");
		lblEmail = new JLabel("Email : ");
		lblPrice = new JLabel("Price : ");
		lblType = new JLabel("Type : ");
		lblDataEntered = new JLabel();
		btnSave = new JButton("Save");
		
		add(lblName);
		add(txtName);
		add(lblEmail);
		add(txtEmail);
		add(lblPrice);
		add(txtPrice);
		add(lblType);
		TypeGrp.add(RbtnSports);
		TypeGrp.add(RbtnEconomical);
		add(RbtnSports);
		add(RbtnEconomical);
		add(btnSave);
		add(lblDataEntered);
		
		btnSave.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			    	
			    	Connection ConnObj = null;
					try {
						Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
						ConnObj=DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
						
						
						System.out.print("Entering Data to Table  : \n");
						
						String Type = "";
						String Name = txtName.getText();
						String Email = txtEmail.getText();
						int Price = Integer.parseInt(txtPrice.getText());
						
						if(RbtnSports.isSelected())
						{
							Type = "Male";
						}
						if(RbtnEconomical.isSelected())
						{
							Type = "Female";
						}

												
						PreparedStatement PrStm = ConnObj.prepareStatement("insert into set5 values (?,?,?,?)");
						PrStm.setString(1,Name);
						PrStm.setString(2, Email);
						PrStm.setInt(3,Price);
						PrStm.setString(4, Type);
						PrStm.executeUpdate();
						
						System.out.print("data Entered \n");
						
					    
						ConnObj.close();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					lblDataEntered.setText("Data Entered ");
					System.out.println("Car namesssss");
					txtName.setText("");
					txtEmail.setText("");
					txtPrice.setText("");
				}
				
		});
		
	}
	}


