package Set5;

import java.awt.FlowLayout;

import Set2.Login2;

public class Main5 {
	public static void main(String[] args) {
		
		Login5 frame = new Login5();
		frame.setLayout(new FlowLayout());
		frame.setSize(500, 500);
		frame.setVisible(true);
	}

}
