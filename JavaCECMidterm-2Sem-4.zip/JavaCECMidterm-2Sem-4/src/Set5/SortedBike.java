package Set5;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class SortedBike extends JFrame{
	
	public SortedBike() {
		// TODO Auto-generated constructor stub
		JTextArea txtDisplay;
		JButton btnSort;
		
		txtDisplay = new JTextArea(20,30);
		btnSort = new JButton("Sort");
		
		add(txtDisplay);
		add(btnSort);
		
		btnSort.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				txtDisplay.setText("");
				Connection Conn = null;
				
					try {
						Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

						Conn = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");

						PreparedStatement PrStm =  Conn.prepareStatement("Select * from set5 order by BikeName ");
						
						ResultSet Result = PrStm.executeQuery();
						
						while(Result.next())
						{
							txtDisplay.append( "Name : " + Result.getInt("BikeName") + "\n" 
						               + "Email : " + Result.getString("Email") + ":" + "\n" 
						               + "Price : " + Result.getInt("Price") + "\n"
						            + "Type :" + Result.getInt("Type") + "\n");
						}
						
						Conn.close();
					} catch (InstantiationException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IllegalArgumentException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (InvocationTargetException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (NoSuchMethodException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SecurityException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
			}
				
			
		});
		
		
	}

}
