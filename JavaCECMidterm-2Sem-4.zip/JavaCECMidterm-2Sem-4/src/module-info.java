/**
 * 
 */
/**
 * 
 */
module JavaCEC {
	requires java.desktop;
	requires java.sql;
}