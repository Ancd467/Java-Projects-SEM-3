package Set3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

public class RegisterCar extends JFrame{
	
	public RegisterCar() {
		// TODO Auto-generated constructor stub
		JTextField txtCarName,txtCarModel,txtCarCompany,txtCarAverage,txtCarPrice;
		JRadioButton RbtnSUV,RbtnSedan;
		JLabel lblCarName,lblCarModel,lblCarCompany,lblCarAverage,lblCarPrice,lblCategory,lblDataEntered;
		JButton btnSave;
		
		txtCarName = new JTextField(10);
		txtCarModel = new JTextField(10);
		txtCarCompany = new JTextField(10);
		txtCarAverage = new JTextField(10);
		txtCarPrice = new JTextField(10);
		RbtnSUV = new JRadioButton("SUV");
		RbtnSedan = new JRadioButton("Sedan");
		ButtonGroup CategoryGrp = new ButtonGroup();
		lblCarName = new JLabel("Car Name : ");
		lblCarModel = new JLabel("Car Model : ");
		lblCarCompany = new JLabel("Car Company : ");
		lblCarAverage = new JLabel("Car Average : ");
		lblCarPrice = new JLabel("Car Price : ");
		lblCategory = new JLabel("Category : ");
		lblDataEntered = new JLabel();
		btnSave = new JButton("Save");
		
		add(lblCarName);
		add(txtCarName);
		add(lblCarModel);
		add(txtCarModel);
		add(lblCarCompany);
		add(txtCarCompany);
		add(lblCarAverage);
		add(txtCarAverage);
		add(lblCarPrice);
		add(txtCarPrice);
		add(lblCategory);
		CategoryGrp.add(RbtnSUV);
		CategoryGrp.add(RbtnSedan);
		add(RbtnSUV);
		add(RbtnSedan);
		add(btnSave);
		add(lblDataEntered);
		
		btnSave.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			    	
			    	Connection ConnObj = null;
					try {
						Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
						ConnObj=DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
						
						
						System.out.print("Entering Data to Table  : \n");
						
						String Category = "";
						String Name = txtCarName.getText();
						String Model = txtCarModel.getText();
						String Company = txtCarCompany.getText();
						int Average = Integer.parseInt(txtCarAverage.getText());
						int Price = Integer.parseInt(txtCarPrice.getText());
						
						if(RbtnSUV.isSelected())
						{
							Category = " SUV ";
						}
						if(RbtnSedan.isSelected())
						{
							Category = " Sedan ";
						}

												
						PreparedStatement PrStm = ConnObj.prepareStatement("insert into set3 values (?,?,?,?,?,?)");
						PrStm.setString(1,Name);
						PrStm.setString(2, Model);
						PrStm.setString(3,Company);
						PrStm.setInt(4, Average);
						PrStm.setInt(4, Price);
						PrStm.setString(4, Category);
						PrStm.executeUpdate();
						
						System.out.print("data Entered \n");
						
					    
						ConnObj.close();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					lblDataEntered.setText("Data Entered ");
					System.out.println("Car namesssss");
					txtCarName.setText("");
					txtCarModel.setText("");
					txtCarCompany.setText("");
					txtCarAverage.setText("");
					txtCarPrice.setText("");
				}
				
		});
	}

}
