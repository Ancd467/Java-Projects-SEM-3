package Set3;

import java.awt.FlowLayout;

public class Main3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login3 frame = new Login3();
		frame.setLayout(new FlowLayout());
		frame.setSize(500, 500);
		frame.setVisible(true);

	}

}
