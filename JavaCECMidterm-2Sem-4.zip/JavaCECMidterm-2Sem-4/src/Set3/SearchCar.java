package Set3;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class SearchCar extends JFrame{
	
	public SearchCar() {
		// TODO Auto-generated constructor stub
		JTextField txtSearchCompany,txtSearchPrice;
		JTextArea txtDisplay;
		JButton btnSearch;
		JLabel lblCompany,lblPrice;
		
		lblCompany = new JLabel("Search Company : ");
		txtSearchCompany = new JTextField(10);
		lblPrice = new JLabel("Search Price : ");
		txtSearchPrice = new JTextField(10);
		txtDisplay = new JTextArea(20,30);
		btnSearch =new JButton("Search");
		
		add(lblCompany);
		add(txtSearchCompany);
		add(lblPrice);
		add(txtSearchPrice);
		add(btnSearch);
		add(txtDisplay);
		
		btnSearch.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				txtDisplay.setText("");
				Connection Conn = null;
				
					try {
						Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

						Conn = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
						
                        String SearchComapny = txtSearchCompany.getText();
                        int SearchPrice = Integer.parseInt(txtSearchPrice.getText());

						PreparedStatement PrStm =  Conn.prepareStatement("Select * from set3 where CarCompany=? and Price=? ");
						PrStm.setString(1,SearchComapny);
						PrStm.setInt(1,SearchPrice);
						
						ResultSet Result = PrStm.executeQuery();
						
						while(Result.next())
						{
							txtDisplay.append( "Car Name : " + Result.getInt("CarName") + "\n" 
						               + "Car Model : " + Result.getString("CarModel") + ":" + "\n" 
						               + "Car Company : " + Result.getInt("CarCompany") + "\n"
						            + "Car Average :" + Result.getInt("CarAverage") + "\n"
						            + "Car Price :" + Result.getInt("CarPrice") + "\n"
						            + "Car Category :" + Result.getInt("CarCategory") + "\n");
						}
						
						Conn.close();
					} catch (InstantiationException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IllegalArgumentException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (InvocationTargetException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (NoSuchMethodException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SecurityException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
			}
		});
	}

}
