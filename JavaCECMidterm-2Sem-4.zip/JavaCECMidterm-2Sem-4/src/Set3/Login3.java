package Set3;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import Set2.Menu2;

public class Login3 extends JFrame {
	
	public Login3() {
		// TODO Auto-generated constructor stub
		JLabel lblFactorial,lblNumber;
		JTextField txtFactorial,txtNumber;
		JButton btnLogin;
		
		lblFactorial = new JLabel("Factorial : ");
		lblNumber= new JLabel("Number : ");
		txtFactorial = new JTextField(10);
		txtNumber = new JTextField(10);
		btnLogin = new JButton("Login");
		
		
		add(lblFactorial);
		add(txtFactorial);
		add(lblNumber);
		add(txtNumber);
		add(btnLogin);
		
		
		btnLogin.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				
				int Factorial = Integer.parseInt(txtFactorial.getText());
				int Number = Integer.parseInt(txtNumber.getText());
				 int factorial = 1;
			        for (int i = 1; i <= Number ; i++) {
			           factorial *= i;
			        }

			        // Check if the first field is equal to the factorial of the second field
			        if (Factorial == factorial) 
				{
					Menu3 frame = new Menu3();
					frame.setLayout(new FlowLayout());
					frame.setSize(500,500);
					frame.setVisible(true);
				}
				else
				{
					System.out.println("Login Unsuccessful");
				}
				
			}
		});
	}

}
