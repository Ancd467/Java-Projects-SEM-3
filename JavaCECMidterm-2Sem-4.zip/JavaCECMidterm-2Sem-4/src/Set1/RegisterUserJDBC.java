package Set1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class RegisterUserJDBC extends JFrame{
	
	public RegisterUserJDBC() {
		// TODO Auto-generated constructor stub
		JTextField txtName,txtEmail,txtPhone;
		JCheckBox ReadingBox,WritingBox;
		JLabel lblName,lblEmail,lblPhone,lblHobbies,lblDataEntered;
		JButton btnSave;
		
		txtName = new JTextField(10);
		txtEmail = new JTextField(10);
		txtPhone = new JTextField(10);
		ReadingBox = new JCheckBox("Reading");
		WritingBox = new JCheckBox("Writing");
		lblName = new JLabel("Name : ");
		lblEmail = new JLabel("Email : ");
		lblPhone = new JLabel("Phone : ");
		lblHobbies = new JLabel("Hobbies : ");
		lblDataEntered = new JLabel();
		btnSave = new JButton("Save");
		
		add(lblName);
		add(txtName);
		add(lblEmail);
		add(txtEmail);
		add(lblPhone);
		add(txtPhone);
		add(lblHobbies);
		add(ReadingBox);
		add(WritingBox);
		add(btnSave);
		add(lblDataEntered);
		
		btnSave.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
			    	
			    	Connection ConnObj = null;
					try {
						Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();
						ConnObj=DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
						
						
						System.out.print("Entering Data to Table  : \n");
						
						String Hobbies = "";
						String Name = txtName.getText();
						String Email = txtEmail.getText();
						int PhoneNo = Integer.parseInt(txtPhone.getText());
						
						if(ReadingBox.isSelected())
						{
							Hobbies += "Reading";
						}
						if(WritingBox.isSelected())
						{
							Hobbies += "Writing";
						}

												
						PreparedStatement PrStm = ConnObj.prepareStatement("insert into set1 values (?,?,?,?)");
						PrStm.setString(1,Name);
						PrStm.setString(2, Email);
						PrStm.setInt(3,PhoneNo);
						PrStm.setString(4, Hobbies);
						PrStm.executeUpdate();
						
						System.out.print("data Entered \n");
						
					    
						ConnObj.close();
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					lblDataEntered.setText("Data Entered ");
					System.out.println("Car namesssss");
					txtName.setText("");
					txtEmail.setText("");
					txtPhone.setText("");
				}
				
		});
		
	}

}
