package Set1;

import java.awt.FlowLayout;

public class Main {
	
	public static void main(String[] args) {
	
		Login frame = new Login();
		frame.setLayout(new FlowLayout());
		frame.setSize(500, 500);
		frame.setVisible(true);
	}
	

}
