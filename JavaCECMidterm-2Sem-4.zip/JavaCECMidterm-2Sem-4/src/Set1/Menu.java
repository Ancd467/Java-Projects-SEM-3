package Set1;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Menu extends JFrame{
	
	public Menu() {
		// TODO Auto-generated constructor stub
		JMenuBar Menu;
		JMenu MnRegister,MnSearch;
		JMenuItem MIRegUser,MISearchUser;
		
		Menu = new JMenuBar();
		MnRegister = new JMenu("Register");
		MnSearch = new JMenu("Search");
		MIRegUser = new JMenuItem("Register an User");
		MISearchUser = new JMenuItem("Search an User");
		
		setJMenuBar(Menu);
		Menu.add(MnRegister);
		Menu.add(MnSearch);
		MnRegister.add(MIRegUser);
		MnSearch.add(MISearchUser);
		
		MIRegUser.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				RegisterUserJDBC frame = new RegisterUserJDBC();
				frame.setLayout(new FlowLayout());
				frame.setSize(500, 500);
				frame.setVisible(true);
			}
		});
		
		MISearchUser.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				SearchUserJDBC frame = new SearchUserJDBC();
				frame.setLayout(new FlowLayout());
				frame.setSize(500, 500);
				frame.setVisible(true);
			}
		});
		
	}

}
