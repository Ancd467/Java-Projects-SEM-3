package Set1;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class SearchUserJDBC extends JFrame{
	
	public SearchUserJDBC() {
		// TODO Auto-generated constructor stub
		JTextField txtSearch;
		JTextArea txtDisplay;
		JButton btnSearch;
		JLabel lblName;
		
		lblName = new JLabel("Search ID : ");
		txtSearch = new JTextField(10);
		txtDisplay = new JTextArea(20,30);
		btnSearch =new JButton("Search");
		
		add(lblName);
		add(txtSearch);
		add(btnSearch);
		add(txtDisplay);
		
		btnSearch.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				txtDisplay.setText("");
				Connection Conn = null;
				
					try {
						Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();

						Conn = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
						
                        String Search = txtSearch.getText();

						PreparedStatement PrStm =  Conn.prepareStatement("Select * from set1 where Name=? ");
						PrStm.setString(1,Search);
						
						ResultSet Result = PrStm.executeQuery();
						
						while(Result.next())
						{
							txtDisplay.append( "Name : " + Result.getInt("Name") + "\n" 
						               + "Email : " + Result.getString("Email") + ":" + "\n" 
						               + "Phone Number : " + Result.getInt("PhoneNo") + "\n"
						            + "Hobbies :" + Result.getInt("Hobbies") + "\n");
						}
						
						Conn.close();
					} catch (InstantiationException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IllegalAccessException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IllegalArgumentException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (InvocationTargetException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (NoSuchMethodException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SecurityException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (SQLException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				
			}
		});
	}
	}


