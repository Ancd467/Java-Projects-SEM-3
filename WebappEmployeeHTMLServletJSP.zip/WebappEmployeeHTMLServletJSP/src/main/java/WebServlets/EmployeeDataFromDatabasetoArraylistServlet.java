package WebServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeDataFromDatabasetoArraylistServlet
 */
@WebServlet("/EmployeeDataFromDatabasetoArraylistServlet")
public class EmployeeDataFromDatabasetoArraylistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeDataFromDatabasetoArraylistServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		
		Connection Conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructors();
			Conn = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
			
			PreparedStatement prstm = Conn.prepareStatement("select * from EmployeeInfo");
			
			ResultSet result = prstm.executeQuery();
			
			ArrayList<EmployeeData> arremplist = new ArrayList();
			
			while(result.next()) {
				
				String Name = result.getString("Name");
                int Age = Integer.parseInt(result.getString("Age"));
                int Salary = Integer.parseInt(result.getString("Salary"));
                
                EmployeeData NewEmp = new EmployeeData();
                
                NewEmp.Name = Name;
                NewEmp.Age = Age;
                NewEmp.Salary = Salary;
                
                arremplist.add(NewEmp);
                
			}
			Conn.close();
			out.println("Data Inserted");
			RequestDispatcher rd = request.getRequestDispatcher("DisplayEmpData.jsp");
			request.setAttribute("EmpData", arremplist);
			rd.forward(request, response);

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.println("Error che Bro!!");
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
