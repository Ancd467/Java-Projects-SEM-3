package WebServlets;

public class EmployeeData {
	
	String Name;
	int Age;
	int Salary;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	public String Name() {
		return Name;
	}
	
	public int Age() {
		return Age;
	}
	
	public int Salary() {
		return Salary;
	}
	
}
