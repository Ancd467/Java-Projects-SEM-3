package WebServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmployeeRegServlet
 */
@WebServlet("/EmployeeRegServlet")
public class EmployeeRegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmployeeRegServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();

		String name =  request.getParameter("name");
		String age =  request.getParameter("age");
		String salary =  request.getParameter("salary");
		
		Connection Conn = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructors();
			Conn = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
             
			PreparedStatement prstm = Conn.prepareStatement("insert into EmployeeInfo values(?,?,?)");
			
			prstm.setString(1, name);
			prstm.setString(2, age);
			prstm.setString(3, salary);
			
			prstm.executeUpdate();
		
		} 
		catch (Exception e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.println("Error Occured!!");
		}
		
        response.sendRedirect("EmployeeDataFromDatabasetoArraylistServlet");
	}

}
