package WebServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EmpSearchDataFromDatabasetoArraylist
 */
@WebServlet("/EmpSearchDataFromDatabasetoArraylist")
public class EmpSearchDataFromDatabasetoArraylist extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EmpSearchDataFromDatabasetoArraylist() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		
		String Name =  request.getParameter("name");
		
		Connection Conn = null;
		try {
			Class.forName( "com.mysql.cj.jdbc.Driver" ).getDeclaredConstructors();
			Conn = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
		
			PreparedStatement prstm = Conn.prepareStatement("select * from EmployeeInfo where Name = ?");
			
			prstm.setString(1, Name);
			
			ResultSet result = prstm.executeQuery();
			
			ArrayList<EmployeeData> arremplist = new ArrayList();
			
			while (result.next()) {
				String name = result.getString("Name");
				int age = Integer.parseInt(result.getString("Age"));
                int salary = Integer.parseInt(result.getString("Salary"));
				
				EmployeeData Emp = new EmployeeData();
				
				Emp.Name = Name;
				Emp.Age = age;
				Emp.Salary = salary;
				
				arremplist.add(Emp);
			}
			
			RequestDispatcher rd = request.getRequestDispatcher("DisplayEmpSearchData.jsp");
			request.setAttribute("EmpSearchData",arremplist);
			rd.forward(request, response);
		
		} catch (Exception e) {
					e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
