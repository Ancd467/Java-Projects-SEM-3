package WebAppServlets;

public class UserData {
	
	String Name,Email,Password;
	int UserId;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return Name + ":" + Email;
	}
	
	public String Name() {
		return Name;
	}

	public String Email() {
		return Email;
	}
	
	public int UserId() {
		return UserId;
	}
	
	public String Password() {
		return Password;
	}
}
