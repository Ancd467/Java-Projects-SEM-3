package WebAppServlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/DataFromDBtoArraylistServlet")
public class DataFromDBtoArraylistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		Connection ConnObj = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructors();
			ConnObj = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
		
		   Statement stm = ConnObj.createStatement();
		   String Query = "select * from user";
		   
		   ResultSet result = stm.executeQuery(Query);
		   
		   ArrayList<UserData> userarrlist;
		   userarrlist = new ArrayList<UserData>();
		   
		   while(result.next())
		   {
			   String name = result.getString("name");
			   String email = result.getString("email");
			   String password = result.getString("password");
			   int UserId = Integer.parseInt(result.getString("UserId"));
			   
			   UserData newUser = new UserData();
			   
			   newUser.Name=name;
			   newUser.Email=email;
			   newUser.Password=password;
			   newUser.UserId=UserId;
			   userarrlist.add(newUser);
		   }
		   ConnObj.close();
		   RequestDispatcher rd = request.getRequestDispatcher("DisplayUserData.jsp");
		   request.setAttribute("UserData", userarrlist);
		   rd.forward(request, response);
		   
 		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}
}