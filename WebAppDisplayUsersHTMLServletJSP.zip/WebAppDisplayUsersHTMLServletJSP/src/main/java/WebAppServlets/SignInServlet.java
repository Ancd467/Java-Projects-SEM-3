package WebAppServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.swing.text.AbstractDocument.Content;

@WebServlet("/SignInServlet")
public class SignInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		out.println("Got the Values");
		Connection ConnObj = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor();
			ConnObj = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
			out.println("Connection Successfull");
			
			PreparedStatement prstm = ConnObj.prepareStatement("Insert into user values (?,?,?,?)");
			out.println("Query Written");
			
			prstm.setInt(1,0);
			prstm.setString(2,name);
			prstm.setString(3,password);
			prstm.setString(4,email);
			out.println("Values Assigned");
			
			prstm.executeUpdate();
			out.println("Query Fired Successfully");
			out.println("Data Inserted Successfully");
			
			ConnObj.close();
			out.println("Connection Closed");
			out.println("<h1><center>Sign - In Successfull</center></h1>");
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.println("Error Data Not Inserted : Went in Catch");
		}
	    response.sendRedirect("Login.html");
		
		
	}

}
