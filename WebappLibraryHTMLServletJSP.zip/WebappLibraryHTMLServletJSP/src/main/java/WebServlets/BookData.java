package WebServlets;

public class BookData {
	
	public String BName;
	public int BCode;
	public String BAuthor;
	public String BGenre;
	public int ID;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString();
	}
	
	public int ID() {
		return ID;
	}
	
	public int BCode() {
		return BCode;
	}
	
	public String BName() {
		return BName;
	}
	public String BAuthor() {
		return BAuthor;
	}
	public String BGenre() {
		return BGenre;
	}
	
	

}
