package WebServlets;

public class StuDataClass {
	
	int UserId;
	String Name;
	String RollNo;
	int JAVAMarks;
	int SLMarks;
	int MathsMarks;
	
	public int UserId() {
		return UserId;
	}
	
	public String Name() {
		return Name;
	}
	
	public String RollNo() {
		return RollNo;
	}
	
	public int JAVAMarks() {
		return JAVAMarks;
	}
	
	public int SLMarks() {
		return SLMarks;
	}
	
	public int MathsMarks() {
		return MathsMarks;
	}

}
