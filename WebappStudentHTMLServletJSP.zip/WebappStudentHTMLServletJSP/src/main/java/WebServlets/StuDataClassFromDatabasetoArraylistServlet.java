package WebServlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import WebServlets.StuDataClass;

/**
 * Servlet implementation class StuDataClassFromDatabasetoArraylistServlet
 */
@WebServlet("/StuDataClassFromDatabasetoArraylistServlet")
public class StuDataClassFromDatabasetoArraylistServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StuDataClassFromDatabasetoArraylistServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
        Connection ConnObj = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructors();
			ConnObj = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
		
		   Statement stm = ConnObj.createStatement();
		   String Query = "select * from stu";
		   
		   ResultSet result = stm.executeQuery(Query);
		   
		   ArrayList<StuDataClass> stuarrlist;
		   stuarrlist = new ArrayList<StuDataClass>();
		   
		   while(result.next())
		   {
			   
			    int UserId = Integer.parseInt(result.getString("UserId"));
				String Name = result.getString("Name");
				String  RollNo = result.getString("RollNo");
				int JAVAMarks = Integer.parseInt(result.getString("JAVAMarks"));
				int SLMarks = Integer.parseInt(result.getString("SLMarks"));
				int MathsMarks = Integer.parseInt(result.getString("MathsMarks"));
			   
			   StuDataClass newStu = new StuDataClass();
			   
			   newStu.UserId = UserId;
			   newStu.Name = Name;
			   newStu.RollNo = RollNo;
			   newStu.JAVAMarks = JAVAMarks;
			   newStu.SLMarks = SLMarks;
			   newStu.MathsMarks = MathsMarks;
			   stuarrlist.add(newStu);
		   }
		   ConnObj.close();
		   RequestDispatcher rd = request.getRequestDispatcher("DisplayStuData.jsp");
		   request.setAttribute("StuData", stuarrlist);
		   rd.forward(request, response);
		   
 		
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}			
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
