package WebServlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StuRegServlet
 */
@WebServlet("/StuRegServlet")
public class StuRegServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public StuRegServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out = response.getWriter();
		
		response.setContentType("text/html");
		
		String Name = request.getParameter("Name");
		String  RollNo = request.getParameter("RollNo");
		int JAVAMarks = Integer.parseInt(request.getParameter("JAVAMarks"));
		int SLMarks = Integer.parseInt(request.getParameter("SLMarks"));
		int MathsMarks = Integer.parseInt(request.getParameter("MathsMarks"));
		out.println("Got the Values");
		
		Connection ConnObj = null;
		
		try {
			Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor();
			ConnObj = DriverManager.getConnection("jdbc:mysql://localhost/student","root","yuval");
			out.println("Connection Successfull");
			
			PreparedStatement prstm = ConnObj.prepareStatement("Insert into stu values (?,?,?,?,?,?)");
			out.println("Query Written");
			
			prstm.setInt(1,0);
			prstm.setString(2,Name);
			prstm.setString(3,RollNo);
			prstm.setInt(4,JAVAMarks);
			prstm.setInt(5,SLMarks);
			prstm.setInt(6,MathsMarks);
			out.println("Values Assigned");
			
			prstm.executeUpdate();
			out.println("Query Fired Successfully");
			out.println("Data Inserted Successfully");
			
			ConnObj.close();
			out.println("Connection Closed");
			out.println("<h1><center>Sign - In Successfull</center></h1>");
		} 
		catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			out.println("Error Data Not Inserted : Went in Catch");
		}
	   response.sendRedirect("StuDataClassFromDatabasetoArraylistServlet");
		
		
	}
	}


